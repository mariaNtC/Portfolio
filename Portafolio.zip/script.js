// ==============================
// SELECTORES BASE
// ==============================
const sections      = [...document.querySelectorAll('section')]
const titleEl       = document.querySelector('.nav-title')
const animator      = document.querySelector('.nav-animator')
const menuItemsLeft = document.querySelectorAll('.menu-item')
const menuItemsRight= document.querySelectorAll('.menu-item-right')
const allMenuLinks  = document.querySelectorAll('a[href^="#"]')


// ==============================
// ESTADO GLOBAL
// ==============================
let currentTitle = ''
let currentIndex = 0
let isScrolling  = false
let scrollTimeout = null


// ==============================
// LOADER INICIAL — malla hex + halo mouse + duración mínima
// ==============================
;(function () {
  const loader = document.getElementById('page-loader')
  if (!loader) return

  // ── Detectar si hay mouse disponible ──
  const hasMouse = window.matchMedia('(hover: hover)').matches
  let autoStart = null   // timestamp de inicio del halo automático

  const canvas = document.getElementById('loader-canvas')
  const ctx = canvas ? canvas.getContext('2d') : null

  // ── Colores reactivos al tema (igual que el Stack) ──
  const COLOR_DARK  = '127, 255, 233'
  const COLOR_LIGHT = '129, 140, 248'
  const isLight = () => document.documentElement.getAttribute('data-theme') === 'light'
  const getColor = () => isLight() ? COLOR_LIGHT : COLOR_DARK
  const getBoost = () => isLight() ? 1.6 : 1

  const HEX_SIZE = 16
  const HALO_R   = 200

  let mouseX = -9999
  let mouseY = -9999
  let rafId = null

const draw = () => {
    if (!ctx) return
    const w = canvas.width
    const h = canvas.height
    ctx.clearRect(0, 0, w, h)

    const colW = HEX_SIZE * Math.sqrt(3)
    const rowH = HEX_SIZE * 1.5

    // ── Banda (como en el Stack): malla solo entre top y bottom ──
    const TOP_OFFSET = 90
    const BOTTOM_PAD = 90
    const bandY = TOP_OFFSET
    const bandH = h - TOP_OFFSET - BOTTOM_PAD

    ctx.save()
    ctx.beginPath()
    ctx.rect(0, bandY, w, bandH)
    ctx.clip()

    // Malla hexagonal
    for (let row = -1; row * rowH < h + HEX_SIZE * 2; row++) {
      for (let col = -1; col * colW < w + colW; col++) {
        const ox = row % 2 === 0 ? 0 : colW / 2
        const cx = col * colW + ox
        const cy = row * rowH
        ctx.beginPath()
        for (let v = 0; v < 6; v++) {
          const angle = (Math.PI / 3) * v - Math.PI / 6
          const vx = cx + HEX_SIZE * 0.78 * Math.cos(angle)
          const vy = cy + HEX_SIZE * 0.78 * Math.sin(angle)
          v === 0 ? ctx.moveTo(vx, vy) : ctx.lineTo(vx, vy)
        }
        ctx.closePath()
        ctx.strokeStyle = `rgba(${getColor()}, ${0.12 * getBoost()})`
        ctx.lineWidth = 0.5
        ctx.stroke()
      }
    }

    // ── Posición del halo: mouse real, o automático en diagonal ──
    let hx = mouseX
    let hy = mouseY

     if (!hasMouse) {
      // Halo automático SOLO en dispositivos sin mouse (mobile/touch)
      if (autoStart === null) autoStart = performance.now()
      const t = ((performance.now() - autoStart) % 2500) / 2500  // 0 a 1, loop 2.5s
      hx = w * t                        // izquierda → derecha
      hy = h - (h * t)                  // abajo → arriba
    }

    // ── Halo (real o automático) ──
    if (hx > 0 && hy > 0) {
      const grad = ctx.createRadialGradient(hx, hy, 0, hx, hy, HALO_R)
      grad.addColorStop(0,    `rgba(${getColor()}, ${0.18 * getBoost()})`)
      grad.addColorStop(0.45, `rgba(${getColor()}, ${0.06 * getBoost()})`)
      grad.addColorStop(1,    `rgba(${getColor()}, 0)`)
      ctx.fillStyle = grad
      ctx.fillRect(0, 0, w, h)

      for (let row = -1; row * rowH < h + HEX_SIZE * 2; row++) {
        for (let col = -1; col * colW < w + colW; col++) {
          const ox = row % 2 === 0 ? 0 : colW / 2
          const nx = col * colW + ox
          const ny = row * rowH
          const dist = Math.hypot(nx - hx, ny - hy)
          if (dist < HALO_R * 0.65) {
            const alpha = (1 - dist / (HALO_R * 0.65)) * 0.65
            ctx.beginPath()
            ctx.arc(nx, ny, 1.8, 0, Math.PI * 2)
            ctx.fillStyle = `rgba(${getColor()}, ${alpha * getBoost()})`
            ctx.fill()
          }
        }
      }
    }

    ctx.restore()  // fin del clip de la banda

    // ── Bordes de la banda con glow neon (como el Stack) ──
    const drawBandEdge = (y, blur, alpha, lw) => {
      const a = alpha * getBoost()
      ctx.save()
      ctx.shadowBlur  = blur
      ctx.shadowColor = `rgba(${getColor()}, ${a})`
      ctx.strokeStyle = `rgba(${getColor()}, ${a})`
      ctx.lineWidth   = lw
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(w, y)
      ctx.stroke()
      ctx.restore()
    }

    drawBandEdge(bandY, 24, 0.12, 4)
    drawBandEdge(bandY,  8, 0.35, 1.5)
    drawBandEdge(bandY,  2, 0.70, 0.8)

    drawBandEdge(bandY + bandH, 24, 0.12, 4)
    drawBandEdge(bandY + bandH,  8, 0.35, 1.5)
    drawBandEdge(bandY + bandH,  2, 0.70, 0.8)
  }

  const resize = () => {
    if (!canvas) return
    canvas.width  = window.innerWidth
    canvas.height = window.innerHeight
    draw()
  }

  const loop = () => {
    draw()
    rafId = requestAnimationFrame(loop)
  }

  // Mouse tracking sobre el loader
  loader.addEventListener('mousemove', (e) => {
    mouseX = e.clientX
    mouseY = e.clientY
  }, { passive: true })

  loader.addEventListener('mouseleave', () => {
    mouseX = -9999
    mouseY = -9999
  })

  window.addEventListener('resize', resize)

  // Arrancar la animación
  if (canvas) {
    resize()
    loop()
  }

  // ── Duración mínima de 2.5s ──
  const MIN_DURATION = 2500
  const startTime = Date.now()

  const hideLoader = () => {
    const remaining = Math.max(0, MIN_DURATION - (Date.now() - startTime))
    setTimeout(() => {
      loader.classList.add('is-loaded')
      // Frenar la animación del canvas y remover
      setTimeout(() => {
        cancelAnimationFrame(rafId)
        loader.remove()
      }, 700)
    }, remaining)
  }

  if (document.readyState === 'complete') {
    hideLoader()
  } else {
    window.addEventListener('load', hideLoader)
  }
})()

// ==============================
// INIT NAV
// ==============================
if (animator && titleEl && sections.length > 0) {
  animator.classList.add('is-visible')
  currentTitle       = sections[0].dataset.title || ''
  titleEl.textContent = currentTitle
}

// ==============================
// TEXTO DINÁMICO
// ==============================
const words = [
  { text: 'usuario curioso de IA',   icon: 'fa-robot' },
  { text: 'de corazón gamer',        icon: 'fa-gamepad' },
  { text: 'merodeador de la naturaleza', icon: 'fa-tree' },
  { text: 'esencialmente cocinero',  icon: 'fa-utensils' },
  { text: 'aprendiz incansable',     icon: 'fa-book-open' },
  { text: 'fiel ladero del mate',    icon: 'fa-mug-hot' },
  { text: 'una mente creativa',          icon: 'fa-lightbulb' },
  { text: 'amante del deporte',      icon: 'fa-basketball' },
  { text: 'detallista por naturaleza', icon: 'fa-magnifying-glass' },
  { text: 'de espíritu contemplativo',  icon: 'fa-spa' }
]

const dynamicText = document.getElementById('dynamic-text')

if (dynamicText) {
  let index = 0

  // Construye el HTML de una frase: texto + ícono
  const render = (i) =>
    `${words[i].text} <i class="fa-solid ${words[i].icon}" aria-hidden="true"></i>`

  // Respeta la preferencia de movimiento reducido del sistema
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches

  dynamicText.innerHTML = render(0)

  const animateText = () => {
    if (reduceMotion) {
      // Sin animación — solo cambia el contenido
      index = (index + 1) % words.length
      dynamicText.innerHTML = render(index)
      setTimeout(animateText, 2500)
      return
    }

    dynamicText.style.opacity   = 0
    dynamicText.style.transform = 'translateY(-4px)'

    setTimeout(() => {
      index = (index + 1) % words.length
      dynamicText.innerHTML       = render(index)
      dynamicText.style.opacity   = 1
      dynamicText.style.transform = 'translateY(0)'

      setTimeout(animateText, 2200)
    }, 350)
  }

  setTimeout(animateText, 2200)
}

// ==============================
// IMAGEN RANDOM EN HOVER
// ==============================
const profileImage = document.getElementById('profile-image')

if (profileImage) {
  const images = [
    'images/profile/1.webp',
    'images/profile/2.webp',
    'images/profile/3.webp',
    'images/profile/4.webp',
    'images/profile/5.webp',
    'images/profile/6.webp',
    'images/profile/7.webp'
  ]

  // Precarga
  images.forEach(src => {
    const img = new Image()
    img.src = src
  })

  let lastIndex = 0

  const getRandomImage = () => {
    let next
    do {
      next = Math.floor(Math.random() * images.length)
    } while (next === lastIndex)
    lastIndex = next
    return images[next]
  }

  const isMobile = window.matchMedia('(max-width: 768px)').matches 
              || window.matchMedia('(hover: none)').matches

let intervalId = null

// 👉 DESKTOP → hover
if (!isMobile) {
  profileImage.addEventListener('mouseenter', () => {
    profileImage.src = getRandomImage()
  })
}

// 👉 MOBILE → autoplay
if (isMobile) {
  intervalId = setInterval(() => {
    profileImage.style.opacity = 0.7

    setTimeout(() => {
      profileImage.src = getRandomImage()
      profileImage.style.opacity = 1
    }, 200)

  }, 3000)
}


}



// ==============================
// THEME TOGGLE
// ==============================
const root     = document.documentElement
const themeBtn = document.getElementById('theme-toggle')

const applyTheme = (theme) => {
  root.setAttribute('data-theme', theme)
  localStorage.setItem('theme', theme)
}

const savedTheme = localStorage.getItem('theme') || 'dark'
applyTheme(savedTheme)

if (themeBtn) {
  themeBtn.addEventListener('click', () => {
    const current = root.getAttribute('data-theme')
    applyTheme(current === 'dark' ? 'light' : 'dark')
  })
}

// ==============================
// CV INTERACCIÓN
// ==============================
document.addEventListener('DOMContentLoaded', () => {
  const cvItem    = document.querySelector('.cv-item')
  const labelText = document.querySelector('.label-text')
  const confirmBtn= document.querySelector('.cv-confirm')
  const cancelBtn = document.querySelector('.cv-cancel')

  if (!cvItem || !labelText || !confirmBtn || !cancelBtn) return

  cvItem.addEventListener('click', (e) => {
    if (!cvItem.classList.contains('confirming')) {
      e.preventDefault()
      cvItem.classList.add('confirming')
      labelText.innerHTML = '¿Descargar<br>currículum?'
    }
  })

  cancelBtn.addEventListener('click', (e) => {
    e.stopPropagation()
    cvItem.classList.remove('confirming')
    labelText.textContent = 'Currículum'
  })

  confirmBtn.addEventListener('click', (e) => {
    e.stopPropagation()
    window.location.href = './files/cv.pdf'
  })
})

// ==============================
// HELPERS — estados activos
// ==============================
const clearActiveStates = () => {
  menuItemsLeft.forEach(i  => i.classList.remove('active'))
  menuItemsRight.forEach(i => i.classList.remove('active'))
}

const setActiveById = (id) => {
  const selector = `[href="#${id}"]`
  menuItemsLeft.forEach(item => {
    item.classList.toggle('active', item.getAttribute('href') === `#${id}`)
  })
  menuItemsRight.forEach(item => {
    item.classList.toggle('active', item.getAttribute('href') === `#${id}`)
  })
}

const setActiveDot = (id) => {
  dots.forEach(dot => dot.classList.toggle('active', dot.dataset.target === id))
}

// ==============================
// ANIMACIÓN DE TÍTULO
// ==============================
const animateTitleChange = (newTitle, newIndex) => {
  if (!titleEl || newTitle === currentTitle) return
  if (titleEl.classList.contains('is-animating')) return

  const direction = newIndex > currentIndex ? 1 : -1

  titleEl.classList.add('is-animating')
  titleEl.style.transition = 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)'
  titleEl.style.transform  = `translateY(${direction * -12}px) scale(0.98)`
  titleEl.style.opacity    = '0'
  titleEl.style.filter     = 'blur(6px)'

  setTimeout(() => {
    titleEl.textContent      = newTitle
    titleEl.style.transition = 'none'
    titleEl.style.transform  = `translateY(${direction * 20}px) scale(0.98)`
    titleEl.style.opacity    = '0'
    titleEl.style.filter     = 'blur(8px)'

    requestAnimationFrame(() => {
      titleEl.style.transition = 'all 0.4s cubic-bezier(0.2, 0.8, 0.2, 1)'
      titleEl.style.transform  = 'translateY(0) scale(1)'
      titleEl.style.opacity    = '1'
      titleEl.style.filter     = 'blur(0)'
    })

    setTimeout(() => titleEl.classList.remove('is-animating'), 0)
  }, 0)

  currentTitle = newTitle
  currentIndex = newIndex
}

// ==============================
// SCROLL CONTROLADO
// ==============================
const scrollToSection = (id) => {
  const target = document.getElementById(id)
  if (!target) return

  isScrolling = true

  clearActiveStates()
  setActiveById(id)
  setActiveDot(id)
  document.body.dataset.activeSection = id

  const newIndex = sections.findIndex(sec => sec.id === id)
  animateTitleChange(target.dataset.title, newIndex)

  target.scrollIntoView({ behavior: 'smooth', block: 'start' })

  clearTimeout(scrollTimeout)

  scrollTimeout = setTimeout(() => {
    isScrolling = false
  }, 700)
}

// ==============================
// CLICK MENÚ → SCROLL
// ==============================
allMenuLinks.forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault()
    scrollToSection(link.getAttribute('href').replace('#', ''))
  })
})

// ==============================
// FLECHA SCROLL → FOOTER
// ==============================
const scrollArrow = document.querySelector('.scroll-arrow-container')
if (scrollArrow) {
  scrollArrow.addEventListener('click', () => scrollToSection('footer'))
}

// ==============================
// DOTS
// ==============================
const dots = document.querySelectorAll('[data-target]')

dots.forEach(dot => {
  // Click
  dot.addEventListener('click', () => scrollToSection(dot.dataset.target))
  // Teclado — accesibilidad (role="button" necesita Enter/Space)
  dot.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault()
      scrollToSection(dot.dataset.target)
    }
  })
})

// ==============================
// INTERSECTION OBSERVER
// ==============================
const observer = new IntersectionObserver((entries) => {
  if (isScrolling) return

  const visible = entries
    .filter(e => e.isIntersecting)
    .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0]

  if (!visible) return

  const id       = visible.target.id
  const newIndex = sections.findIndex(sec => sec.id === id)

  clearActiveStates()
  setActiveById(id)
  setActiveDot(id)
  document.body.dataset.activeSection = id
  animateTitleChange(visible.target.dataset.title, newIndex)

}, { threshold: [0.3, 0.3, 0.3] })

sections.forEach(section => observer.observe(section))



// ==============================
// CONTACT FORM
// Requiere EmailJS cargado en el HTML:
// <script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>
//
// Reemplazá estas 3 constantes con tus datos de EmailJS:
const EMAILJS_SERVICE_ID  = 'service_uf2r8pm'
const EMAILJS_TEMPLATE_ID = 'template_uvtqknv'
const EMAILJS_PUBLIC_KEY  = 'L99uG3OEvEM77pPqh'
// ==============================

document.addEventListener('DOMContentLoaded', () => {

  const form       = document.getElementById('contact-form')
  const submitBtn  = document.getElementById('cf-submit-btn')
  const statusEl   = form?.querySelector('.cf-status')
  const contactInput = document.getElementById('cf-contact')
  const textarea   = document.getElementById('cf-message')
  const charCount  = form?.querySelector('.cf-char-count')
  const toggleBtns = form?.querySelectorAll('.cf-toggle-btn')

  if (!form) return

  // ==============================
  // INICIALIZAR EMAILJS
  // ==============================
  if (typeof emailjs !== 'undefined') {
    emailjs.init(EMAILJS_PUBLIC_KEY)
  }

  // ==============================
  // TOGGLE MAIL / TELÉFONO
  // ==============================
  let contactType = 'email'

  toggleBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.dataset.type

      toggleBtns.forEach(b => {
        b.classList.remove('active')
        b.setAttribute('aria-pressed', 'false')
      })
      btn.classList.add('active')
      btn.setAttribute('aria-pressed', 'true')

      contactType = type
      contactInput.value = ''
      clearError(contactInput)

      if (type === 'email') {
        contactInput.type        = 'email'
        contactInput.placeholder = 'tu@email.com'
        contactInput.autocomplete = 'email'
      } else {
        contactInput.type        = 'tel'
        contactInput.placeholder = '+54 11 1234-5678'
        contactInput.autocomplete = 'tel'
      }

      contactInput.focus()
    })
  })

  // ==============================
  // CONTADOR DE CARACTERES
  // ==============================
  if (textarea && charCount) {
    const max = parseInt(textarea.maxLength)

    textarea.addEventListener('input', () => {
      const len = textarea.value.length
      charCount.textContent = `${len} / ${max}`

      charCount.classList.remove('cf-char-warn', 'cf-char-limit')
      if (len >= max) {
        charCount.classList.add('cf-char-limit')
      } else if (len >= max * 0.85) {
        charCount.classList.add('cf-char-warn')
      }
    })
  }

  // ==============================
  // VALIDACIÓN
  // ==============================
  const showError = (input) => input.classList.add('cf-error')
  const clearError = (input) => input.classList.remove('cf-error')

  const validateForm = () => {
    let valid = true
    const subject = document.getElementById('cf-subject')
    const message = document.getElementById('cf-message')

    ;[subject, contactInput, message].forEach(clearError)

    if (!subject.value.trim()) {
      showError(subject)
      valid = false
    }

    if (contactType === 'email') {
      const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRe.test(contactInput.value.trim())) {
        showError(contactInput)
        valid = false
      }
    } else {
      // Teléfono: mínimo 7 dígitos
      const phoneRe = /[\d]{7,}/
      if (!phoneRe.test(contactInput.value.replace(/\s|-/g, ''))) {
        showError(contactInput)
        valid = false
      }
    }

    if (!message.value.trim()) {
      showError(message)
      valid = false
    }

    return valid
  }

  // Limpiar error al escribir
  form.querySelectorAll('.cf-input, .cf-textarea').forEach(el => {
    el.addEventListener('input', () => clearError(el))
  })

  // ==============================
  // ESTADO DE ENVÍO
  // ==============================
  const setStatus = (type, msg) => {
    statusEl.textContent = msg
    statusEl.className   = `cf-status cf-status--${type}`
  }

  const setSending = (sending) => {
    submitBtn.disabled = sending
    submitBtn.classList.toggle('cf-submit--sending', sending)

    const icon = submitBtn.querySelector('.cf-submit__icon i')
    const text = submitBtn.querySelector('.cf-submit__text')

    if (sending) {
      icon.className  = 'fa-solid fa-circle-notch'
      text.textContent = 'Enviando...'
    } else {
      icon.className  = 'fa-solid fa-paper-plane'
      text.textContent = 'Enviar mensaje'
    }
  }

  // ==============================
  // SUBMIT
  // ==============================
  form.addEventListener('submit', async (e) => {
    e.preventDefault()

    if (!validateForm()) {
      setStatus('error', '✖ Revisá los campos marcados.')
      return
    }

    setSending(true)
    setStatus('', '')

    const templateParams = {
      subject:      document.getElementById('cf-subject').value.trim(),
      contact_type: contactType === 'email' ? 'Email' : 'Teléfono',
      contact:      contactInput.value.trim(),
      message:      document.getElementById('cf-message').value.trim(),
    }

    try {
      if (typeof emailjs === 'undefined') {
        throw new Error('EmailJS no está cargado.')
      }

      await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, templateParams)

      setStatus('ok', '✓ Mensaje enviado. Te respondo pronto.')
      form.reset()
      if (charCount) charCount.textContent = '0 / 800'

    } catch (err) {
      console.error('EmailJS error:', err)
      setStatus('error', 'No se pudo enviar. Intentá por mail directamente.')
    } finally {
      setSending(false)
    }
  })

})

// ==============================
// ABOUT — CAROUSEL
// ==============================
;(function () {

  // Breakpoints deben coincidir exactamente con los del SCSS
  const BP_MOBILE  = 650    // ≤ 650 → 1 card
  const BP_TABLET_SM = 850  // 651–850 → 2 cards, gap 14px
  const BP_TABLET  = 1024   // 851–1024 → 2 cards, gap 20px
                            // > 1024 → 3 cards, gap 20px

  const track    = document.querySelector('.about-track')
  const prevBtn  = document.querySelector('.about-arrow--prev')
  const nextBtn  = document.querySelector('.about-arrow--next')
  const dotsWrap = document.querySelector('.about-dots')

  if (!track || !prevBtn || !nextBtn) return

  const cards = [...track.querySelectorAll('.about-card')]
  const total = cards.length

  let current = 0

  // ── Cuántas cards mostrar según viewport ──
  const getVisible = () => {
    const w = window.innerWidth
    if (w <= BP_MOBILE)  return 1
    if (w <= BP_TABLET_SM)  return 1 
    if (w <= BP_TABLET)  return 2
     // cubre 651–1024px (incluye tablet chica)
    return 3
  }

  // ── Gap real según breakpoint (debe coincidir con SCSS) ──
  const getGap = () => {
    const w = window.innerWidth
    if (w <= BP_MOBILE)    return 10
    if (w <= BP_TABLET_SM) return 5  // @media (max-width: 850px)
    return 20
  }

  // ── Máximo índice de desplazamiento ──
  const maxIndex = () => Math.max(0, total - getVisible())

  // ── Generar dots ──
  const buildDots = () => {
    dotsWrap.innerHTML = ''
    const count = maxIndex() + 1
    for (let i = 0; i < count; i++) {
      const dot = document.createElement('button')
      dot.type = 'button'
      dot.className = 'about-dot' + (i === current ? ' active' : '')
      dot.setAttribute('aria-label', `Ir a posición ${i + 1}`)
      dot.setAttribute('role', 'tab')
      dot.addEventListener('click', () => goTo(i))
      dotsWrap.appendChild(dot)
    }
  }

  // ── Actualizar dots activos ──
  const updateDots = () => {
    const dotEls = dotsWrap.querySelectorAll('.about-dot')
    dotEls.forEach((d, i) => d.classList.toggle('active', i === current))
  }

  // ── Calcular y aplicar transform ──
  const goTo = (index) => {
    current = Math.max(0, Math.min(index, maxIndex()))

    // Medimos el ancho real de la card en el DOM + el gap del CSS
    const cardEl = cards[0]
    const cardW  = cardEl.getBoundingClientRect().width + getGap()

    track.style.transform = `translateX(-${current * cardW}px)`

    prevBtn.disabled = current === 0
    nextBtn.disabled = current >= maxIndex()

    updateDots()
  }

  // ── Navegación ──
  prevBtn.addEventListener('click', () => goTo(current - 1))
  nextBtn.addEventListener('click', () => goTo(current + 1))

  // ── Teclado ──
  document.addEventListener('keydown', (e) => {
    const section = document.getElementById('about')
    if (!section) return
    const rect = section.getBoundingClientRect()
    const inView = rect.top < window.innerHeight && rect.bottom > 0
    if (!inView) return

    if (e.key === 'ArrowLeft')  goTo(current - 1)
    if (e.key === 'ArrowRight') goTo(current + 1)
  })

  // ── Swipe táctil ──
  let touchStartX = 0
  let touchDeltaX = 0

  track.addEventListener('touchstart', (e) => {
    touchStartX = e.touches[0].clientX
    touchDeltaX = 0
  }, { passive: true })

  track.addEventListener('touchmove', (e) => {
    touchDeltaX = e.touches[0].clientX - touchStartX
  }, { passive: true })

  track.addEventListener('touchend', () => {
    if (Math.abs(touchDeltaX) > 50) {
      touchDeltaX < 0 ? goTo(current + 1) : goTo(current - 1)
    }
    touchDeltaX = 0
  })

  // ── Resize — debounced ──
  let resizeTimer
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer)
    resizeTimer = setTimeout(() => {
      buildDots()
      goTo(Math.min(current, maxIndex()))
    }, 150)
  })
  

  // ── Init ──
  buildDots()
  goTo(0)

})()

// ==============================
// STACK — Canvas (banda + malla hex + halo) + Tilt 3D
// ==============================
;(function () {

  const canvas  = document.querySelector('.stack-bg-canvas')
  const section = document.getElementById('stack')
  if (!canvas || !section) return

  const ctx = canvas.getContext('2d')

  // Color reactivo al tema:
  //   dark  → neon teal     (127, 255, 233) → #7fffe9
  //   light → accent indigo (129, 140, 248) → #818cf8
  const COLOR_DARK  = '127, 255, 233'
  const COLOR_LIGHT = '129, 140, 248'

  // Fondos reactivos al tema
  const BG_DARK  = '#03060d'   // negro azulado profundo
  const BG_LIGHT = '#eef0f7'   // gris muy claro con leve tinte azul

  // Helpers reactivos — leen el tema en cada frame
  const isLight = () =>
    document.documentElement.getAttribute('data-theme') === 'light'

  const getColor = () => isLight() ? COLOR_LIGHT : COLOR_DARK
  const getBg    = () => isLight() ? BG_LIGHT   : BG_DARK

  // Multiplicador de intensidad — light necesita más opacidad
  // porque el accent indigo tiene menos contraste sobre fondo claro
  const getBoost = () => isLight() ? 1.6 : 1

  let mouseX = -9999
  let mouseY = -9999

  // ══════════════════════════════════════════
  // BANDA — altura fija, centrada verticalmente
  // ══════════════════════════════════════════
 const HEX_SIZE   = 16     // px — tamaño del hexágono
  const HALO_R     = 200    // px — radio del halo del mouse

  // Margen superior reservado para el título "Stack & Skills"
  const TOP_OFFSET = 120    // px — espacio del título arriba
  const BOTTOM_PAD = 40     // px — pequeño respiro abajo

  // La banda ahora se calcula dinámicamente: ocupa casi toda la sección,
  // dejando afuera el título arriba y un respiro abajo. Se adapta a la
  // altura real del contenido (cards + timeline de formación).
  const getBand = (w, h) => ({
    x: 0,
    y: TOP_OFFSET,
    w: w,
    h: h - TOP_OFFSET - BOTTOM_PAD,
  })

  // ══════════════════════════════════════════
  // DRAW
  // ══════════════════════════════════════════
  const draw = () => {
    const w = canvas.width
    const h = canvas.height
    ctx.clearRect(0, 0, w, h)

    // Fondo negro
    ctx.fillStyle = getBg()
    ctx.fillRect(0, 0, w, h)

    const band = getBand(w, h)

    // ── Clip a la banda ──
    ctx.save()
    ctx.beginPath()
    ctx.rect(band.x, band.y, band.w, band.h)
    ctx.clip()

    // ── Malla hexagonal ──
    const colW = HEX_SIZE * Math.sqrt(3)
    const rowH = HEX_SIZE * 1.5

    for (let row = -1; row * rowH < h + HEX_SIZE * 2; row++) {
      for (let col = -1; col * colW < w + colW; col++) {
        const ox = row % 2 === 0 ? 0 : colW / 2
        const cx = col * colW + ox
        const cy = row * rowH

        ctx.beginPath()
        for (let v = 0; v < 6; v++) {
          const angle = (Math.PI / 3) * v - Math.PI / 6
          const vx = cx + HEX_SIZE * 0.78 * Math.cos(angle)
          const vy = cy + HEX_SIZE * 0.78 * Math.sin(angle)
          v === 0 ? ctx.moveTo(vx, vy) : ctx.lineTo(vx, vy)
        }
        ctx.closePath()
        ctx.strokeStyle = `rgba(${getColor()}, ${0.12 * getBoost()})`
        ctx.lineWidth = 0.5
        ctx.stroke()
      }
    }

    // ── Halo del mouse (solo si está sobre la sección) ──
    if (mouseX > 0 && mouseY > 0) {
      // Gradiente radial desde el mouse
      const grad = ctx.createRadialGradient(
        mouseX, mouseY, 0,
        mouseX, mouseY, HALO_R
      )
      grad.addColorStop(0,    `rgba(${getColor()}, ${0.18 * getBoost()})`)
      grad.addColorStop(0.45, `rgba(${getColor()}, ${0.06 * getBoost()})`)
      grad.addColorStop(1,    `rgba(${getColor()}, 0)`)
      ctx.fillStyle = grad
      ctx.fillRect(0, 0, w, h)

      // Nodos de la malla iluminados por el halo
      for (let row = -1; row * rowH < h + HEX_SIZE * 2; row++) {
        for (let col = -1; col * colW < w + colW; col++) {
          const ox = row % 2 === 0 ? 0 : colW / 2
          const nx = col * colW + ox
          const ny = row * rowH
          const dist = Math.hypot(nx - mouseX, ny - mouseY)
          if (dist < HALO_R * 0.65) {
            const alpha = (1 - dist / (HALO_R * 0.65)) * 0.65
            ctx.beginPath()
            ctx.arc(nx, ny, 1.8, 0, Math.PI * 2)
            ctx.fillStyle = `rgba(${getColor()}, ${alpha * getBoost()})`
            ctx.fill()
          }
        }
      }
    }

    ctx.restore() // fin del clip de la banda

    // ── Bordes de la banda con glow ──
    const drawBandEdge = (y, blur, alpha, lw) => {
      const a = alpha * getBoost()
      ctx.save()
      ctx.shadowBlur  = blur
      ctx.shadowColor = `rgba(${getColor()}, ${a})`
      ctx.strokeStyle = `rgba(${getColor()}, ${a})`
      ctx.lineWidth   = lw
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(w, y)
      ctx.stroke()
      ctx.restore()
    }

    // Borde superior
    drawBandEdge(band.y, 24, 0.12, 4)
    drawBandEdge(band.y,  8, 0.35, 1.5)
    drawBandEdge(band.y,  2, 0.70, 0.8)

    // Borde inferior
    drawBandEdge(band.y + band.h, 24, 0.12, 4)
    drawBandEdge(band.y + band.h,  8, 0.35, 1.5)
    drawBandEdge(band.y + band.h,  2, 0.70, 0.8)
  }

  // ══════════════════════════════════════════
  // RESIZE
  // ══════════════════════════════════════════
 const resize = () => {
    canvas.width  = document.documentElement.clientWidth   // ancho del viewport
    canvas.height = section.offsetHeight
    draw()
  }

  // ══════════════════════════════════════════
  // LOOP — solo cuando la sección es visible
  // ══════════════════════════════════════════
  let rafId  = null
  let active = false

  const loop = () => {
    if (!active) return
    draw()
    rafId = requestAnimationFrame(loop)
  }

  new IntersectionObserver((entries) => {
    active = entries[0].isIntersecting
    if (active) loop()
    else { cancelAnimationFrame(rafId); rafId = null }
  }, { threshold: 0.05 }).observe(section)

  // Mouse tracking
  section.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect()
    mouseX = e.clientX - rect.left
    mouseY = e.clientY - rect.top
  }, { passive: true })

  section.addEventListener('mouseleave', () => {
    mouseX = -9999
    mouseY = -9999
  })

  // Resize debounced
  let resizeTimer
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer)
    resizeTimer = setTimeout(resize, 150)
  })

  resize()

  // ══════════════════════════════════════════
  // TILT 3D — cards
  // ══════════════════════════════════════════
  const MAX_TILT = 8

  document.querySelectorAll('#stack .stack-card[data-tilt]').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect()
      const dx   = (e.clientX - rect.left - rect.width  / 2) / (rect.width  / 2)
      const dy   = (e.clientY - rect.top  - rect.height / 2) / (rect.height / 2)

      card.style.transform = `perspective(800px) rotateX(${-dy * MAX_TILT}deg) rotateY(${dx * MAX_TILT}deg) scale3d(1.02,1.02,1.02)`

      const mx = ((e.clientX - rect.left) / rect.width  * 100).toFixed(1)
      const my = ((e.clientY - rect.top)  / rect.height * 100).toFixed(1)
      card.style.setProperty('--mx', `${mx}%`)
      card.style.setProperty('--my', `${my}%`)
    }, { passive: true })

    card.addEventListener('mouseleave', () => {
      card.style.transform = ''
    })
  })

})()

// ==============================
// PROJECTS — Filtrado por tabs
// ==============================
;(function () {

  const section = document.getElementById('projects')
  if (!section) return

  const tabs    = section.querySelectorAll('.projects-tab')
  const cards   = section.querySelectorAll('.project-card')
  const empty   = section.querySelector('.projects-empty')
  const grid    = section.querySelector('.projects-grid')

  if (!tabs.length || !cards.length) return

  // Filtra cards según la categoría activa
  // 'all' muestra todas, las demás muestran solo las que matchean data-category
  const filterCards = (category) => {
    let visibleCount = 0

    cards.forEach(card => {
      const cardCat = card.dataset.category
      const shouldShow = category === 'all' || cardCat === category

      if (shouldShow) {
        card.hidden = false
        visibleCount++
      } else {
        card.hidden = true
      }
    })

    // Empty state — visible solo cuando no hay cards en esa categoría
    if (empty) {
      empty.hidden = visibleCount > 0
    }

    // Reseteamos el scroll del grid al cambiar de tab — mejor UX
    if (grid) grid.scrollTop = 0
  }

  // Cambia la tab activa actualizando ARIA y clases
  const setActiveTab = (clickedTab) => {
    tabs.forEach(tab => {
      const isActive = tab === clickedTab
      tab.classList.toggle('is-active', isActive)
      tab.setAttribute('aria-selected', isActive ? 'true' : 'false')
    })
  }

  // Listeners
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const category = tab.dataset.tab
      setActiveTab(tab)
      filterCards(category)
    })
  })

  // Estado inicial — la tab "all" está activa por defecto en el HTML
  filterCards('all')

})()

// ==============================
// EDU TIMELINE — tap para expandir en mobile
// En desktop el hover maneja todo por CSS; este JS solo agrega
// el toggle por click/tap (necesario en touch donde no hay hover).
// ==============================
;(function () {

  const timeline = document.querySelector('.edu-timeline')
  if (!timeline) return

  const nodes = timeline.querySelectorAll('.edu-node')
  if (!nodes.length) return

  // Solo togglear en mobile/touch — en desktop el hover maneja la card
  const isMobile = () => window.matchMedia('(max-width: 850px)').matches

  nodes.forEach(node => {
    node.addEventListener('click', (e) => {
      if (!isMobile()) return   // en desktop, el click no fija nada

      const isOpen = node.getAttribute('aria-expanded') === 'true'
      nodes.forEach(n => n.setAttribute('aria-expanded', 'false'))
      node.setAttribute('aria-expanded', isOpen ? 'false' : 'true')
    })
  })

  // Cerrar al hacer click fuera del timeline (solo relevante en mobile)
  document.addEventListener('click', (e) => {
    if (!timeline.contains(e.target)) {
      nodes.forEach(n => n.setAttribute('aria-expanded', 'false'))
    }
  })

})()

// ==============================
// MODAL DE DIPLOMAS
// ==============================
;(function () {
  const modal = document.getElementById('diploma-modal')
  if (!modal) return

  const modalImg     = document.getElementById('diploma-modal-img')
  const officialLink = document.getElementById('diploma-official-link')
  const codeBtn      = document.getElementById('diploma-code-btn')
  const codeText     = codeBtn?.querySelector('.diploma-modal__code-text')
  const diplomaLinks = document.querySelectorAll('[data-diploma]')

  let currentCode = ''

  const openModal = (imgSrc, officialUrl, name, code) => {
    modalImg.src = imgSrc
    modalImg.alt = `Diploma: ${name}`
    officialLink.href = officialUrl

    // Mostrar el botón de código solo si el diploma tiene uno
    if (code) {
      currentCode = code
      codeText.textContent = 'Código de verificación'
      codeBtn.classList.remove('is-copied')
      codeBtn.hidden = false
    } else {
      codeBtn.hidden = true
      currentCode = ''
    }

    modal.setAttribute('aria-hidden', 'false')
    document.body.classList.add('modal-open')
  }

  const closeModal = () => {
    modal.setAttribute('aria-hidden', 'true')
    document.body.classList.remove('modal-open')
    setTimeout(() => { modalImg.src = '' }, 300)
  }

  diplomaLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault()
      const img      = link.dataset.diplomaImg
      const official = link.dataset.diplomaOfficial
      const code     = link.dataset.diplomaCode || ''
      const card     = link.closest('.edu-card')
      const name     = card?.querySelector('.edu-card__name')?.textContent || 'Diploma'
      openModal(img, official, name, code)
    })
  })

  // Copiar código al portapapeles
  if (codeBtn) {
    codeBtn.addEventListener('click', async () => {
      if (!currentCode) return
      try {
        await navigator.clipboard.writeText(currentCode)
        codeBtn.classList.add('is-copied')
        codeText.textContent = '¡Copiado!'
        setTimeout(() => {
          codeBtn.classList.remove('is-copied')
          codeText.textContent = 'Código de verificación'
        }, 2000)
      } catch (err) {
        // Fallback si el navegador bloquea clipboard
        codeText.textContent = currentCode
      }
    })
  }

  modal.querySelectorAll('[data-close]').forEach(el => {
    el.addEventListener('click', closeModal)
  })
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false') {
      closeModal()
    }
  })
})()

// ==============================
// MODAL DE IDENTIDAD DE MARCA
// ==============================
;(function () {
  const modal = document.getElementById('brand-modal')
  if (!modal) return

  const modalImg = document.getElementById('brand-modal-img')
  const scrollBox = modal.querySelector('.brand-modal__scroll')
  const triggers = document.querySelectorAll('[data-brandmodal]')

  const openModal = (imgSrc) => {
    modalImg.src = imgSrc
    modal.classList.remove('is-zoomed')
    modal.setAttribute('aria-hidden', 'false')
    document.body.classList.add('modal-open')
  }

  const closeModal = () => {
    modal.setAttribute('aria-hidden', 'true')
    modal.classList.remove('is-zoomed')
    document.body.classList.remove('modal-open')
    setTimeout(() => { modalImg.src = '' }, 300)
  }

  // Click en la imagen → zoom hacia el punto clickeado
  modalImg.addEventListener('click', (e) => {
    const isZoomed = modal.classList.contains('is-zoomed')

    if (!isZoomed) {
      // Calcular en qué porcentaje de la imagen cayó el click
      const rect = modalImg.getBoundingClientRect()
      const clickX = (e.clientX - rect.left) / rect.width   // 0 a 1
      const clickY = (e.clientY - rect.top) / rect.height   // 0 a 1

      // Agrandar
      modal.classList.add('is-zoomed')

      // Tras el reflow, scrollear para centrar el punto clickeado
      requestAnimationFrame(() => {
        const newW = modalImg.offsetWidth
        const newH = modalImg.offsetHeight
        // Posición objetivo del punto dentro de la imagen ampliada
        const targetX = clickX * newW
        const targetY = clickY * newH
        // Centrar ese punto en el viewport del contenedor
        scrollBox.scrollLeft = targetX - scrollBox.clientWidth / 2
        scrollBox.scrollTop  = targetY - scrollBox.clientHeight / 2
      })
    } else {
      // Volver a normal
      modal.classList.remove('is-zoomed')
      scrollBox.scrollLeft = 0
      scrollBox.scrollTop = 0
    }
  })

  triggers.forEach(btn => {
    btn.addEventListener('click', () => {
      openModal(btn.dataset.brandImg)
    })
  })

  modal.querySelectorAll('[data-brand-close]').forEach(el => {
    el.addEventListener('click', closeModal)
  })
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false') {
      closeModal()
    }
  })
})()

// ==============================
// DESCARGA APK / QR
// ==============================
;(function () {
  const qrModal = document.getElementById('qr-modal')
  const downloadBtns = document.querySelectorAll('[data-apk-download]')
  if (!qrModal || !downloadBtns.length) return

  const qrImg      = document.getElementById('qr-modal-img')
  const directLink = document.getElementById('qr-modal-direct')
  const webLink    = document.getElementById('qr-modal-web')

  const openQR = (qrSrc, apkUrl, webUrl) => {
    qrImg.src = qrSrc
    directLink.href = apkUrl
    webLink.href = webUrl
    qrModal.setAttribute('aria-hidden', 'false')
    document.body.classList.add('modal-open')
  }

  const closeQR = () => {
    qrModal.setAttribute('aria-hidden', 'true')
    document.body.classList.remove('modal-open')
  }

  // Siempre abre el modal — las opciones de descarga están adentro
  downloadBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      openQR(btn.dataset.qrImg, btn.dataset.apkUrl, btn.dataset.appWeb)
    })
  })

  qrModal.querySelectorAll('[data-qr-close]').forEach(el => {
    el.addEventListener('click', closeQR)
  })
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && qrModal.getAttribute('aria-hidden') === 'false') {
      closeQR()
    }
  })
})()